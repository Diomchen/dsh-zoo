#!/usr/bin/env node
/**
 * 桌面 helper 的真机冒烟（只在 macOS + 本机有 Electron 时有意义；不进 npm test）。
 *
 * 覆盖 ticket 07 + 08 的验收：
 *   1. 宠物真的画出来：截图模式用 capturePage() 抓 PNG + 同名 .json，zlib 自己解 PNG，
 *      断言背景透明、每只宠物的媒体区/昵称条有像素、素材走 localpet://（source=video）；
 *   2. 点击穿透：渲染端悬停路径、主进程兜底（forward 失效）、主进程否决（光标真在外面）、
 *      渲染端冻结后 fail-closed；
 *   3. 输入租约：拖拽时把光标移到宠物矩形外，窗口仍保持可交互；pointerup 后立刻交还穿透；
 *      busy 心跳冻结后超过 BUSY_LEASE_MS 自动释放；
 *   4. 物理：渲染端 60fps 跑重力/反弹/边缘夹取，逐帧上报的矩形与主进程命中判定一致；
 *      拖拽跟手、松手有速度、几秒后速度衰减且不出界；
 *   5. 场景 v2：宿主删/加宠物、改动作，渲染端跟着增删，reset 会重新出生；
 *   6. 生命周期：quit / 崩溃重启 / dispose / 宿主被 SIGKILL 都不留进程。
 *
 * 抓图是这台机器上唯一能看到窗口的办法（没有屏幕录制权限）。设
 *   LOCAL_PET_SMOKE_NOTES=1 npm run smoke:desktop
 * 会把整窗（棋盘格合成）和宠物特写写进 .scratch/local-pet/notes/。
 *
 * 只依赖 node:zlib，不装任何包。
 */

import { spawn } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { deflateSync, inflateSync } from 'node:zlib'

import shared from '../desktop/shared.js'
import { createDesktop, HELPER_MAIN } from '../src/desktop.js'
import { buildHelperArgs, helperEnv, resolveElectronBinary } from '../src/desktop-launch.js'
import { resolveDshPetAssetDirs } from '../src/pet-assets.js'

const HERE = dirname(fileURLToPath(import.meta.url))
const ROOT = join(HERE, '..')
const OUT_DIR = join(tmpdir(), 'dsh-local-pet-desktop-smoke-' + process.pid)
const NOTES_DIR = join(ROOT, '.scratch', 'local-pet', 'notes')
const WRITE_NOTES = process.env.LOCAL_PET_SMOKE_NOTES === '1'
const ASSET_ROOTS = resolveDshPetAssetDirs({ env: process.env })
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const spawned = []
let checks = 0

function pass (message) {
  checks += 1
  console.log('  ok  ' + message)
}

function info (message) {
  console.log('      ' + message)
}

async function run (name, fn) {
  console.log('\n# ' + name)
  const started = Date.now()
  const result = await fn()
  console.log('  (' + ((Date.now() - started) / 1000).toFixed(1) + 's)')
  return result
}

function assert (condition, message) {
  if (!condition) throw new Error('断言失败：' + message)
  pass(message)
}

// ---------------------------------------------------------------------------
// 极简 PNG 解码/编码（8-bit RGBA，非隔行）——为了不依赖任何 npm 包
// ---------------------------------------------------------------------------

function decodePng (buffer) {
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
  if (!buffer.subarray(0, 8).equals(signature)) throw new Error('不是 PNG')
  let offset = 8
  let width = 0
  let height = 0
  let bitDepth = 0
  let colorType = 0
  let interlace = 0
  const idat = []
  while (offset + 8 <= buffer.length) {
    const length = buffer.readUInt32BE(offset)
    const type = buffer.toString('ascii', offset + 4, offset + 8)
    const data = buffer.subarray(offset + 8, offset + 8 + length)
    if (type === 'IHDR') {
      width = data.readUInt32BE(0)
      height = data.readUInt32BE(4)
      bitDepth = data[8]
      colorType = data[9]
      interlace = data[12]
    } else if (type === 'IDAT') {
      idat.push(data)
    } else if (type === 'IEND') {
      break
    }
    offset += 12 + length
  }
  if (bitDepth !== 8 || interlace !== 0 || (colorType !== 6 && colorType !== 2)) {
    throw new Error('不支持的 PNG：bitDepth=' + bitDepth + ' colorType=' + colorType + ' interlace=' + interlace)
  }
  const channels = colorType === 6 ? 4 : 3
  const stride = width * channels
  const raw = inflateSync(Buffer.concat(idat))
  const out = Buffer.alloc(height * stride)
  let previous = Buffer.alloc(stride)
  for (let row = 0; row < height; row += 1) {
    const filter = raw[row * (stride + 1)]
    const line = raw.subarray(row * (stride + 1) + 1, row * (stride + 1) + 1 + stride)
    const current = Buffer.alloc(stride)
    for (let index = 0; index < stride; index += 1) {
      const left = index >= channels ? current[index - channels] : 0
      const up = previous[index]
      const upperLeft = index >= channels ? previous[index - channels] : 0
      let value = line[index]
      if (filter === 1) value = (value + left) & 0xff
      else if (filter === 2) value = (value + up) & 0xff
      else if (filter === 3) value = (value + Math.floor((left + up) / 2)) & 0xff
      else if (filter === 4) {
        const p = left + up - upperLeft
        const pa = Math.abs(p - left)
        const pb = Math.abs(p - up)
        const pc = Math.abs(p - upperLeft)
        const predictor = pa <= pb && pa <= pc ? left : (pb <= pc ? up : upperLeft)
        value = (value + predictor) & 0xff
      } else if (filter !== 0) {
        throw new Error('未知 PNG filter ' + filter)
      }
      current[index] = value
    }
    current.copy(out, row * stride)
    previous = current
  }
  if (channels === 3) {
    const rgba = Buffer.alloc(width * height * 4)
    for (let index = 0; index < width * height; index += 1) {
      rgba[index * 4] = out[index * 3]
      rgba[index * 4 + 1] = out[index * 3 + 1]
      rgba[index * 4 + 2] = out[index * 3 + 2]
      rgba[index * 4 + 3] = 255
    }
    return { width, height, channels: 4, data: rgba }
  }
  return { width, height, channels: 4, data: out }
}

const CRC_TABLE = (() => {
  const table = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c
  }
  return table
})()

function crc32 (buffer) {
  let c = 0xffffffff
  for (let index = 0; index < buffer.length; index += 1) c = CRC_TABLE[(c ^ buffer[index]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function pngChunk (type, data) {
  const head = Buffer.alloc(8)
  head.writeUInt32BE(data.length, 0)
  head.write(type, 4, 'ascii')
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(Buffer.concat([head.subarray(4), data])), 0)
  return Buffer.concat([head, data, crc])
}

function encodePng (image) {
  const { width, height, data } = image
  const stride = width * 4
  const raw = Buffer.alloc((stride + 1) * height)
  for (let row = 0; row < height; row += 1) {
    raw[row * (stride + 1)] = 0
    data.copy(raw, row * (stride + 1) + 1, row * stride, row * stride + stride)
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr[8] = 8
  ihdr[9] = 6
  ihdr[10] = 0
  ihdr[11] = 0
  ihdr[12] = 0
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0))
  ])
}

function pixelAt (image, x, y) {
  const index = (y * image.width + x) * 4
  return [image.data[index], image.data[index + 1], image.data[index + 2], image.data[index + 3]]
}

function countOpaque (image, left, top, right, bottom, threshold = 0) {
  let count = 0
  const x0 = Math.max(0, Math.floor(left))
  const y0 = Math.max(0, Math.floor(top))
  const x1 = Math.min(image.width, Math.ceil(right))
  const y1 = Math.min(image.height, Math.ceil(bottom))
  for (let y = y0; y < y1; y += 1) {
    for (let x = x0; x < x1; x += 1) {
      if (image.data[(y * image.width + x) * 4 + 3] > threshold) count += 1
    }
  }
  return count
}

function countTransparent (image) {
  let transparent = 0
  for (let index = 3; index < image.data.length; index += 4) {
    if (image.data[index] === 0) transparent += 1
  }
  return transparent
}

/** 棋盘格合成：让透明度在一张不透明的 PNG 里肉眼可辨。 */
function compositeOverCheckerboard (image, square = 64) {
  const out = Buffer.alloc(image.width * image.height * 4)
  const light = [237, 242, 248]
  const dark = [198, 208, 220]
  for (let y = 0; y < image.height; y += 1) {
    for (let x = 0; x < image.width; x += 1) {
      const index = (y * image.width + x) * 4
      const alpha = image.data[index + 3] / 255
      const background = (Math.floor(x / square) + Math.floor(y / square)) % 2 === 0 ? light : dark
      out[index] = Math.round(image.data[index] * alpha + background[0] * (1 - alpha))
      out[index + 1] = Math.round(image.data[index + 1] * alpha + background[1] * (1 - alpha))
      out[index + 2] = Math.round(image.data[index + 2] * alpha + background[2] * (1 - alpha))
      out[index + 3] = 255
    }
  }
  return { width: image.width, height: image.height, channels: 4, data: out }
}

/** 2×2/4×4 盒式降采样（先合成到不透明背景，避免透明像素被平均成灰边）。 */
function downscale (image, factor) {
  const width = Math.max(1, Math.floor(image.width / factor))
  const height = Math.max(1, Math.floor(image.height / factor))
  const out = Buffer.alloc(width * height * 4)
  const area = factor * factor
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      let r = 0
      let g = 0
      let b = 0
      let a = 0
      for (let dy = 0; dy < factor; dy += 1) {
        for (let dx = 0; dx < factor; dx += 1) {
          const sx = Math.min(image.width - 1, x * factor + dx)
          const sy = Math.min(image.height - 1, y * factor + dy)
          const index = (sy * image.width + sx) * 4
          r += image.data[index]
          g += image.data[index + 1]
          b += image.data[index + 2]
          a += image.data[index + 3]
        }
      }
      const index = (y * width + x) * 4
      out[index] = Math.round(r / area)
      out[index + 1] = Math.round(g / area)
      out[index + 2] = Math.round(b / area)
      out[index + 3] = Math.round(a / area)
    }
  }
  return { width, height, channels: 4, data: out }
}

function cropImage (image, left, top, width, height) {
  const out = Buffer.alloc(width * height * 4)
  for (let y = 0; y < height; y += 1) {
    image.data.copy(out, y * width * 4, ((top + y) * image.width + left) * 4, ((top + y) * image.width + left + width) * 4)
  }
  return { width, height, channels: 4, data: out }
}

// ---------------------------------------------------------------------------
// 截图断言
// ---------------------------------------------------------------------------

function verifyShot (pngPath, sidecarPath, expectedPets, options = {}) {
  const sidecar = JSON.parse(readFileSync(sidecarPath, 'utf8'))
  const image = decodePng(readFileSync(pngPath))
  const bounds = sidecar.bounds
  const scaleX = image.width / bounds.width
  const scaleY = image.height / bounds.height
  const toPixel = (localX, localY) => [Math.round(localX * scaleX), Math.round(localY * scaleY)]

  assert(scaleX === scaleY, '截图像素与逻辑坐标同尺度（scale=' + scaleX + '）')
  assert(image.width === Math.round(bounds.width * scaleX) && image.height === Math.round(bounds.height * scaleY),
    '截图尺寸 = 窗口 bounds × scale（' + image.width + '×' + image.height + '）')
  assert(sidecar.scene.version === 2, 'sidecar 里是场景 v2')
  const pets = sidecar.renderer !== null && Array.isArray(sidecar.renderer.pets)
    ? sidecar.renderer.pets
    : sidecar.scene.items
  assert(pets.length === expectedPets, 'sidecar 里有 ' + expectedPets + ' 只宠物（实际 ' + pets.length + '）')

  const corner = pixelAt(image, 2, 2)
  assert(corner[3] === 0, '窗口背景是透明的（左上角 alpha=0）')
  const transparent = countTransparent(image)
  assert(transparent / (image.width * image.height) > 0.9,
    '整张图 >90% 像素透明（' + ((transparent / (image.width * image.height)) * 100).toFixed(2) + '%）')

  for (const pet of pets) {
    assert(pet.x >= 0 && pet.y >= 0 &&
      pet.x + pet.width <= bounds.width + 0.5 && pet.y + pet.height <= bounds.height + 0.5,
    '宠物 ' + pet.id + ' 在工作区内')
    const [px, py] = toPixel(pet.x, pet.y)
    const mediaWidth = Math.round(pet.width * scaleX)
    const mediaHeight = Math.round(Math.min(pet.width, pet.height) * scaleY)
    const mediaPixels = countOpaque(image, px, py, px + mediaWidth, py + mediaHeight, 0)
    assert(mediaPixels > mediaWidth * mediaHeight * 0.003,
      '宠物 ' + pet.id + ' 的媒体区有可见像素（' + mediaPixels + '）')
    const namePixels = countOpaque(image, px, py + mediaHeight, px + mediaWidth, py + Math.round(pet.height * scaleY), 0)
    assert(namePixels > 80, '宠物 ' + pet.id + ' 的昵称条画出来了（' + namePixels + ' px）')
  }

  const videos = pets.filter((pet) => pet.source === 'video')
  const svgs = pets.filter((pet) => pet.source === 'svg')
  if (options.source === 'svg') {
    assert(svgs.length === pets.length, '没有素材时所有宠物都退到内置 SVG 色块')
  } else if (options.source === 'video' || ASSET_ROOTS.length > 0) {
    assert(videos.length === pets.length,
      '所有宠物都通过 localpet:// 加载了 dsh-pet WebM（' + videos.map((pet) => pet.clip).join(', ') + '）')
  } else {
    info('没有找到 dsh-pet 素材：宠物退到内置 SVG 色块')
    assert(svgs.length === pets.length, '没有素材时全部退到 SVG')
  }
  return { image, sidecar, pets, scaleX, scaleY, bounds }
}

function writeNoteScreenshots (verified) {
  if (!WRITE_NOTES) return null
  mkdirSync(NOTES_DIR, { recursive: true })
  const composite = compositeOverCheckerboard(verified.image)
  const full = downscale(composite, 4)
  const fullPath = join(NOTES_DIR, '08-desktop-pets-composited.png')
  writeFileSync(fullPath, encodePng(full))

  // 宠物特写：自己的那只 + 四周 110 逻辑 px，能看清素材和昵称。
  const focus = verified.pets.find((pet) => pet.role === 'self') ?? verified.pets[0]
  const margin = 110
  const left = focus.x
  const top = focus.y
  const px = Math.max(0, Math.floor((left - margin) * verified.scaleX))
  const py = Math.max(0, Math.floor((top - margin) * verified.scaleY))
  const pw = Math.min(composite.width - px, Math.ceil((focus.width + margin * 2) * verified.scaleX))
  const ph = Math.min(composite.height - py, Math.ceil((focus.height + margin * 2) * verified.scaleY))
  const crop = downscale(cropImage(composite, px, py, pw, ph), 2)
  const cropPath = join(NOTES_DIR, '08-desktop-pets-crop-composited.png')
  writeFileSync(cropPath, encodePng(crop))
  return { fullPath, cropPath }
}

// ---------------------------------------------------------------------------
// 控件截图（ticket 11）：弹层按钮 + 放行卡 + 失败气泡
// ---------------------------------------------------------------------------

function rectCenterScreen (rect, workArea) {
  return {
    x: Math.round(workArea.x + rect.x + rect.width / 2),
    y: Math.round(workArea.y + rect.y + rect.height / 2)
  }
}

function overlapsRect (a, b) {
  return a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height
}

/**
 * 两个矩形之间那个“缝”里的一点（窗口局部坐标），用于验证弹层的桥接矩形。
 * 弹层可能被摆在宠物的右/左/上/下，这里按最近的一条边算；重叠则返回 null。
 */
function gapPointBetween (a, b) {
  const mid = (start, end) => (start + end) / 2
  if (a.x + a.width <= b.x) {
    return {
      x: mid(a.x + a.width, b.x),
      y: mid(Math.max(a.y, b.y), Math.min(a.y + a.height, b.y + b.height))
    }
  }
  if (b.x + b.width <= a.x) {
    return {
      x: mid(b.x + b.width, a.x),
      y: mid(Math.max(a.y, b.y), Math.min(a.y + a.height, b.y + b.height))
    }
  }
  if (a.y + a.height <= b.y) {
    return {
      x: mid(Math.max(a.x, b.x), Math.min(a.x + a.width, b.x + b.width)),
      y: mid(a.y + a.height, b.y)
    }
  }
  if (b.y + b.height <= a.y) {
    return {
      x: mid(Math.max(a.x, b.x), Math.min(a.x + a.width, b.x + b.width)),
      y: mid(b.y + b.height, a.y)
    }
  }
  return null
}

/** 控件区域必须真的有像素：不是“DOM 里存在”而是画出来了。 */
function assertControlPixels (verified, rects) {
  for (const rect of rects) {
    const [px, py] = [
      Math.round(rect.x * verified.scaleX),
      Math.round(rect.y * verified.scaleY)
    ]
    const pw = Math.max(1, Math.round(rect.width * verified.scaleX))
    const ph = Math.max(1, Math.round(rect.height * verified.scaleY))
    const pixels = countOpaque(verified.image, px, py, px + pw, py + ph, 8)
    assert(pixels > pw * ph * 0.25,
      '控件 ' + rect.id + ' 在截图里有可见像素（' + pixels + '/' + (pw * ph) + '）')
  }
}

function writeControlNotes (verified, noticeVerified) {
  if (!WRITE_NOTES) return null
  mkdirSync(NOTES_DIR, { recursive: true })
  const composite = compositeOverCheckerboard(verified.image)
  const fullPath = join(NOTES_DIR, '11-desktop-controls-composited.png')
  writeFileSync(fullPath, encodePng(downscale(composite, 4)))

  const ui = Array.isArray(verified.sidecar.renderer?.uiRects) ? verified.sidecar.renderer.uiRects : []
  const self = verified.pets.find((pet) => pet.role === 'self') ?? verified.pets[0]
  const boxes = [{ x: self.x, y: self.y, width: self.width, height: self.height }, ...ui]
  const left = Math.max(0, Math.min(...boxes.map((box) => box.x)) - 70)
  const top = Math.max(0, Math.min(...boxes.map((box) => box.y)) - 90)
  const right = Math.min(verified.bounds.width, Math.max(...boxes.map((box) => box.x + box.width)) + 70)
  const bottom = Math.min(verified.bounds.height, Math.max(...boxes.map((box) => box.y + box.height)) + 60)
  const crop = downscale(cropImage(
    composite,
    Math.floor(left * verified.scaleX),
    Math.floor(top * verified.scaleY),
    Math.ceil((right - left) * verified.scaleX),
    Math.ceil((bottom - top) * verified.scaleY)
  ), 2)
  const cropPath = join(NOTES_DIR, '11-desktop-controls-crop-composited.png')
  writeFileSync(cropPath, encodePng(crop))

  let noticePath = null
  if (noticeVerified !== null && noticeVerified !== undefined) {
    const noticeComposite = compositeOverCheckerboard(noticeVerified.image)
    const noticeSelf = noticeVerified.pets.find((pet) => pet.role === 'self') ?? noticeVerified.pets[0]
    const nLeft = Math.max(0, Math.floor(noticeSelf.x - 160))
    const nTop = Math.max(0, Math.floor(noticeSelf.y - 220))
    const nRight = Math.min(noticeVerified.bounds.width, Math.ceil(noticeSelf.x + noticeSelf.width + 380))
    const nBottom = Math.min(noticeVerified.bounds.height, Math.ceil(noticeSelf.y + noticeSelf.height + 80))
    const nCrop = downscale(cropImage(
      noticeComposite,
      Math.floor(nLeft * noticeVerified.scaleX),
      Math.floor(nTop * noticeVerified.scaleY),
      Math.ceil((nRight - nLeft) * noticeVerified.scaleX),
      Math.ceil((nBottom - nTop) * noticeVerified.scaleY)
    ), 2)
    noticePath = join(NOTES_DIR, '11-desktop-controls-notice-composited.png')
    writeFileSync(noticePath, encodePng(nCrop))
  }
  return { fullPath, cropPath, noticePath }
}

// ---------------------------------------------------------------------------
// 直接 stdio 客户端
// ---------------------------------------------------------------------------

function createHelperClient (log, extraArgs = [], clientOptions = {}) {
  const resolved = resolveElectronBinary({})
  assert(resolved.ok, '找到 Electron：' + resolved.path)
  const args = buildHelperArgs({
    helperPath: HELPER_MAIN,
    hostPid: process.pid,
    debug: true,
    assetRoots: clientOptions.withAssets === false ? [] : ASSET_ROOTS
  }).concat(extraArgs)
  const child = spawn(resolved.path, args, {
    cwd: ROOT,
    env: helperEnv(process.env, process.pid),
    stdio: ['pipe', 'pipe', 'pipe']
  })
  spawned.push(child)
  const events = []
  const stderr = []
  const parser = shared.createLineParser()
  child.stdout.setEncoding('utf8')
  child.stdout.on('data', (chunk) => {
    for (const entry of parser.push(chunk)) {
      if (entry.type === 'oversize') continue
      if (entry.type !== 'line' || entry.line.trim() === '') continue
      const parsed = shared.parseLine(entry.line)
      if (!parsed.ok) {
        log('非 JSON stdout：' + entry.line.slice(0, 200))
        continue
      }
      const normalized = shared.normalizeHelperEvent(parsed.value)
      if (!normalized.ok) {
        log('非法事件：' + normalized.error + ' ' + entry.line.slice(0, 200))
        continue
      }
      events.push(normalized.event)
    }
  })
  child.stderr.setEncoding('utf8')
  child.stderr.on('data', (chunk) => {
    const line = String(chunk).trim()
    if (line !== '') {
      stderr.push(line)
      log('helper stderr: ' + line.slice(0, 240))
    }
  })
  const exited = new Promise((resolve) => child.once('exit', (code, signal) => resolve({ code, signal })))

  const send = (command) => child.stdin.write(JSON.stringify(command) + '\n')
  const mark = () => events.length
  const waitFrom = async (start, predicate, timeoutMs, label) => {
    const deadline = Date.now() + timeoutMs
    while (Date.now() < deadline) {
      for (let index = start; index < events.length; index += 1) {
        if (predicate(events[index])) return events[index]
      }
      await sleep(25)
    }
    throw new Error('等待超时：' + label)
  }
  const status = async () => {
    const start = mark()
    send({ type: 'status', id: 'smoke-status-' + Date.now() })
    const event = await waitFrom(start, (candidate) => candidate.type === 'status', 3000, 'status')
    return event.status
  }
  const rendererState = async () => {
    const start = mark()
    send({ type: 'debug-renderer', id: 'smoke-renderer-' + Date.now() })
    const event = await waitFrom(start, (candidate) => candidate.type === 'renderer-state', 3000, 'renderer-state')
    return event.state
  }
  const waitStatus = async (predicate, timeoutMs, label) => {
    const deadline = Date.now() + timeoutMs
    let last = null
    while (Date.now() < deadline) {
      last = await status()
      if (predicate(last)) return last
      await sleep(60)
    }
    throw new Error('等待状态超时：' + label + '（最后 ' + JSON.stringify(last) + '）')
  }
  return { child, events, send, mark, waitFrom, status, waitStatus, rendererState, exited, stderr }
}

function screenCenter (pet, workArea) {
  return {
    x: workArea.x + pet.x + pet.width / 2,
    y: workArea.y + pet.y + pet.height / 2
  }
}

function hitMatchesPet (hit, pet, workArea, tolerance = 2) {
  if (hit.rect === null) return false
  return Math.abs(hit.rect.x - (workArea.x + pet.x)) <= tolerance &&
    Math.abs(hit.rect.y - (workArea.y + pet.y)) <= tolerance &&
    Math.abs(hit.rect.width - pet.width) <= tolerance &&
    Math.abs(hit.rect.height - pet.height) <= tolerance
}

async function leavePointer (client, point) {
  // 让渲染端也看见光标离开（合成 pointermove；不依赖 hit 事件——本来就穿透时不会发）。
  client.send({ type: 'debug-dispatch', phase: 'move', x: point.x, y: point.y })
  client.send({ type: 'pointer', x: point.x, y: point.y })
  return client.waitStatus((status) => status.ignoring === true, 2500, '恢复穿透')
}

// ---------------------------------------------------------------------------
// 1) 截图模式：自己画三只演示宠物，抓图后退出
// ---------------------------------------------------------------------------

async function verifyShotMode () {
  const pngPath = join(OUT_DIR, 'standalone.png')
  const client = createHelperClient((line) => info(line), [
    '--local-pet-shot', pngPath,
    '--local-pet-shot-delay', '1200'
  ])
  const exit = await Promise.race([client.exited, sleep(20000).then(() => null)])
  assert(exit !== null, '截图模式在 20s 内自己退出')
  assert(exit.code === 0 || exit.code === null, '截图模式退出码正常（' + JSON.stringify(exit) + '）')
  assert(existsSync(pngPath), 'shot 落盘：' + pngPath)
  assert(existsSync(pngPath + '.json'), 'shot sidecar 落盘：' + pngPath + '.json')
  const verified = verifyShot(pngPath, pngPath + '.json', 3, { source: ASSET_ROOTS.length > 0 ? 'video' : 'svg' })
  info('截图：' + pngPath + '（' + verified.image.width + '×' + verified.image.height + '）')
  if (ASSET_ROOTS.length > 0) info('素材根：' + ASSET_ROOTS.join(' | '))
  return { pngPath, sidecarPath: pngPath + '.json', verified }
}

async function verifySvgFallback () {
  const pngPath = join(OUT_DIR, 'no-assets.png')
  const client = createHelperClient((line) => info(line), [
    '--local-pet-shot', pngPath,
    '--local-pet-shot-delay', '200'
  ], { withAssets: false })
  const exit = await Promise.race([client.exited, sleep(20000).then(() => null)])
  assert(exit !== null, '无素材的截图模式也在 20s 内退出')
  assert(exit.code === 0 || exit.code === null, '无素材的截图模式退出码正常（' + JSON.stringify(exit) + '）')
  assert(existsSync(pngPath), '无素材 shot 落盘：' + pngPath)
  const verified = verifyShot(pngPath, pngPath + '.json', 3, { source: 'svg' })
  info('无素材降级截图：' + pngPath)
  return verified
}

// ---------------------------------------------------------------------------
// 2) 控件（ticket 11）：hover → 弹层 → 租约 → 按钮申请 → 失败气泡 → 放行卡 → 送客/召回
// ---------------------------------------------------------------------------

async function verifyControls () {
  const client = createHelperClient((line) => info(line))
  const readyMark = client.mark()
  const ready = await client.waitFrom(readyMark, (event) => event.type === 'ready', 15000, 'ready')
  const workArea = ready.workArea
  const visitorId = '33333333-3333-4333-8333-333333333333'
  const promptId = '44444444-4444-4444-8444-444444444444'
  const outside = { x: workArea.x + 8, y: workArea.y + 8 }

  // 冒烟只走合成输入：真实鼠标/焦点事件不能干扰租约用例。
  client.send({ type: 'debug-lock-input', locked: true })
  await sleep(150)

  const scene = shared.petScene([
    { id: 'self', role: 'self', label: '小蓝', anim: '东张西望', color: shared.PET_COLORS[0] },
    { id: 'visitor:' + visitorId, role: 'visitor', label: '阿蟹', anim: '螃蟹走路', color: shared.PET_COLORS[1] },
    { id: 'guest:demo', role: 'guest', label: '泡泡', anim: '原地小憩沉眠', color: shared.PET_COLORS[2] }
  ], workArea, {
    reset: true,
    controls: {
      visit: { enabled: true, reason: null },
      recall: { enabled: false, nickname: null },
      visitors: [{ deviceId: visitorId, label: '阿蟹' }],
      prompt: { deviceId: promptId, nickname: '泡泡' },
      notice: null
    }
  })
  client.send({ type: 'update', scene })
  await sleep(1800)

  let state = await client.rendererState()
  assert(state !== null && state.pets.length === 3, '控件场景里有 3 只宠物')
  assert(state.controls.prompt !== null && state.controls.prompt.nickname === '泡泡',
    '场景里的 prompt → 放行卡出现')
  assert(state.controls.popover === null, '没有悬停时弹层是关着的')
  let current = await client.status()
  assert(current.overlayRects >= 3, '放行卡的命中矩形已经单独上报（' + current.overlayRects + ' 块）')

  // 悬停自己的宠物：弹层出现，但**不拿输入租约**（A2：整窗不能被一个弹层按 12 秒）。
  let self = state.pets.find((pet) => pet.id === 'self')
  let center = screenCenter(self, workArea)
  let start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  const hoverHit = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '悬停自己')
  assert(hoverHit.itemId === 'self', '悬停命中自己的宠物')
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.popover !== null
  }, 2500, '悬停后弹层出现')
  current = await client.status()
  assert(current.busy === false, '弹层不持有输入租约（A2）')
  assert(current.ignoring === false, '弹层打开时窗口可交互（靠命中矩形，不靠租约）')
  assert(current.overlayRects >= 6, '弹层+按钮+卡片都有独立命中矩形（' + current.overlayRects + ' 块）')

  state = await client.rendererState()
  const selfRect = { x: self.x, y: self.y, width: self.width, height: self.height }
  const popoverRect = state.uiRects.find((rect) => rect.id === 'ui:popover')
  const bridgeRect = state.uiRects.find((rect) => rect.id === 'ui:bridge:popover')
  const promptRect = state.uiRects.find((rect) => rect.id === 'ui:prompt')
  const visitButton = state.uiRects.find((rect) => rect.id === 'ui:btn:visit')
  assert(Boolean(popoverRect), '弹层有命中矩形')
  assert(Boolean(bridgeRect), '宠物与弹层之间有桥接矩形（不靠租约也能跨过间隙）')
  assert(Boolean(promptRect), '放行卡有命中矩形')
  assert(Boolean(visitButton), '「串门」按钮有命中矩形')
  assert(!overlapsRect(popoverRect, selfRect), '弹层不遮挡宠物本体')
  assert(!overlapsRect(promptRect, selfRect), '放行卡不遮挡宠物本体')

  // 桥接矩形真的盖住了宠物与弹层之间的那几像素（纯几何，不动光标）。
  const gapPoint = gapPointBetween(selfRect, popoverRect)
  assert(gapPoint !== null, '能找到宠物与弹层之间的空隙')
  assert(shared.hitTestRects([bridgeRect], gapPoint) !== null, '桥接矩形覆盖宠物与弹层之间的空隙')
  assert(shared.hitTestRects([selfRect, popoverRect], gapPoint) === null, '这个点确实既不在宠物上也不在弹层上')

  // A2 的验收条件：弹层开着、光标既不在宠物上也不在弹层上 → 整个窗口必须恢复穿透。
  // 这里只动主进程光标（渲染端仍以为光标在宠物上），穿透只能来自“真实光标不在命中区”。
  start = client.mark()
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  const cleared = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === false, 3000, '弹层开着也恢复穿透')
  assert(cleared.reason === 'outside', '恢复穿透是因为真实光标不在命中区（reason=' + cleared.reason + '）')
  assert((await client.status()).busy === false, '穿透时也没有残留租约')
  state = await client.rendererState()
  assert(state.controls.popover !== null, '穿透不是“关掉弹层”：弹层仍然开着')

  // 光标移进宠物与弹层之间的缝隙：桥接矩形接管鼠标（不需要租约）。
  start = client.mark()
  client.send({ type: 'pointer', x: workArea.x + gapPoint.x, y: workArea.y + gapPoint.y })
  const gapHit = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '间隙命中')
  assert(['ui:bridge:popover', 'ui:popover'].includes(gapHit.itemId),
    '光标在间隙里时窗口接管鼠标（不靠租约，itemId=' + gapHit.itemId + '）')

  // 光标从缝隙回到宠物上：一直可交互（没有状态翻转，所以不会有新的 hit 事件）。
  client.send({ type: 'pointer', x: center.x, y: center.y })
  await sleep(150)
  assert((await client.status()).ignoring === false, '光标回到宠物上仍然可交互，弹层可以继续用')

  // 截图：弹层按钮 + 放行卡同框。
  mkdirSync(OUT_DIR, { recursive: true })
  const pngPath = join(OUT_DIR, 'controls.png')
  start = client.mark()
  client.send({ type: 'shot', id: 'shot-controls', path: pngPath })
  const shot = await client.waitFrom(start, (event) => event.type === 'shot' && event.id === 'shot-controls', 8000, '控件截图')
  assert(shot.width > 0 && existsSync(pngPath), '控件截图落盘：' + pngPath)
  const verified = verifyShot(pngPath, pngPath + '.json', 3)
  assertControlPixels(verified, [popoverRect, promptRect, visitButton])
  const sidecarUi = verified.sidecar.renderer?.uiRects ?? []
  assert(sidecarUi.some((rect) => rect.id === 'ui:btn:visit'), '截图 sidecar 记录了按钮矩形')

  // 点「串门」：渲染端只发申请，helper 把它写进 stdio 给宿主。
  const visitPoint = rectCenterScreen(visitButton, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'click', x: visitPoint.x, y: visitPoint.y })
  const action = await client.waitFrom(start, (event) => event.type === 'action', 3000, '串门申请')
  assert(action.action === 'visit', '「串门」按钮点击 → 宿主收到 action=visit')
  assert(typeof action.id === 'string' && action.id !== '', 'action 带 id，宿主才能对上是哪一次点击')
  assert(action.deviceId === null, '串门由宿主随机挑邻居，不带 deviceId')

  // 失败必须冒泡：宿主回 ok:false + notice，渲染端在宠物旁边显示几秒。
  client.send({
    type: 'action-result',
    id: action.id,
    ok: false,
    notice: '还没有人放行你，宠物出不了门。'
  })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.notice !== null && /还没有人放行你/.test(snapshot.controls.notice.text)
  }, 2500, '失败气泡出现')
  state = await client.rendererState()
  assert(state.controls.popover === null, '点完动作弹层关闭')
  await waitUntil(async () => {
    const status = await client.status()
    return status.busy === false
  }, 2500, '点完动作后没有残留租约')

  // 保留一张失败气泡的截图（和放行卡同框，证明“不静默”）。
  const noticePng = join(OUT_DIR, 'controls-notice.png')
  start = client.mark()
  client.send({ type: 'shot', id: 'shot-notice', path: noticePng })
  await client.waitFrom(start, (event) => event.type === 'shot' && event.id === 'shot-notice', 8000, '失败气泡截图')
  const noticeVerified = verifyShot(noticePng, noticePng + '.json', 3)

  // 气泡在几秒后自己消失。
  await sleep(4600)
  state = await client.rendererState()
  assert(state.controls.notice === null, '失败气泡几秒后自动消失（不会永久糊在桌面上）')

  // 把两个光标都移开 → 恢复穿透；这是“控件关闭必须交还桌面”的底线。
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  client.send({ type: 'debug-dispatch', phase: 'move', x: outside.x, y: outside.y })
  await client.waitStatus((status) => status.ignoring === true, 3000, '关闭控件后恢复穿透')
  assert((await client.status()).busy === false, '关闭控件后没有残留租约')

  // 放行卡是常驻控件、不持有租约：只把主进程光标放到卡片上，也必须能接管鼠标。
  // 渲染端此刻完全没消息（光标在空白处），走的是 overlay 矩形 + 300ms 主进程兜底。
  state = await client.rendererState()
  const cardRect = state.uiRects.find((rect) => rect.id === 'ui:prompt')
  assert(Boolean(cardRect), '放行卡仍然可见（还没决定）')
  const cardPoint = rectCenterScreen(cardRect, workArea)
  start = client.mark()
  client.send({ type: 'pointer', x: cardPoint.x, y: cardPoint.y })
  const cardHit = await client.waitFrom(start,
    (event) => event.type === 'hit' && event.interactive === true, 3000, '放行卡命中')
  assert(cardHit.itemId === 'ui:prompt', '放行卡自身的矩形让窗口接管鼠标（itemId=' + cardHit.itemId + '）')
  assert((await client.status()).ignoring === false, '光标压在放行卡上时可交互（不靠租约）')
  start = client.mark()
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === false, 3000, '离开放行卡恢复穿透')

  // 拖拽租约的 fail-closed：冻结 busy 续期后，主进程必须按 BUSY_LEASE_MS 收回。
  // （弹层不再持有租约，这条路径现在由拖拽负责——它也确实是唯一需要租约的地方。）
  state = await client.rendererState()
  self = state.pets.find((pet) => pet.id === 'self')
  center = screenCenter(self, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '泄漏前悬停')
  client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
  await client.waitStatus((status) => status.busy === true, 2000, '再次持有租约')
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  client.send({ type: 'debug-freeze-busy', frozen: true })
  current = await client.waitStatus((status) => status.busy === false, shared.BUSY_LEASE_MS + 2500, '泄漏租约 fail-closed')
  assert(current.ignoring === true, '主进程按 BUSY_LEASE_MS 收回泄漏租约并恢复穿透')
  state = await client.rendererState()
  assert(state.dragging === 'self', '此时渲染端仍然在拖拽：桌面靠主进程收回租约恢复穿透')
  client.send({ type: 'debug-freeze-busy', frozen: false })
  client.send({ type: 'debug-dispatch', phase: 'up', x: outside.x, y: outside.y })
  await client.waitStatus((status) => status.busy === false && status.ignoring === true, 3500, '松开后回到穿透')
  assert((await client.rendererState()).dragging === null, '渲染端也收手了')

  // 硬上限：渲染端活着、心跳也一直在续，但一条租约连续持有超过 BUSY_MAX_MS 必须收回。
  // 用调试命令把 30s 缩短到 700ms；收回后 blocked 是粘滞的，悬停不能复活，只认 busy:false。
  state = await client.rendererState()
  self = state.pets.find((pet) => pet.id === 'self')
  center = screenCenter(self, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '硬上限前悬停')
  client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
  await client.waitStatus((status) => status.busy === true, 2000, '硬上限前持有租约')
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  client.send({ type: 'debug-busy-max', ms: 700 })
  current = await client.waitStatus((status) => status.busyBlocked === true, 4000, '硬上限收回租约')
  assert(current.busy === false && current.ignoring === true,
    '租约连续持有超过硬上限 → 主进程收回并标记 blocked（busy=false, blocked=true）')
  state = await client.rendererState()
  assert(state.dragging === 'self', '硬上限收回时渲染端仍在拖拽：窗口仍恢复穿透')
  client.send({ type: 'debug-dispatch', phase: 'up', x: outside.x, y: outside.y })
  await client.waitStatus((status) => status.busyBlocked === false && status.ignoring === true, 3500,
    '显式放手清除 blocked')
  client.send({ type: 'debug-busy-max', ms: 0 })

  // 点击客人 → 弹层（送客）。
  state = await client.rendererState()
  const visitor = state.pets.find((pet) => pet.id === 'visitor:' + visitorId)
  const visitorPoint = screenCenter(visitor, workArea)
  client.send({ type: 'debug-dispatch', phase: 'click', x: visitorPoint.x, y: visitorPoint.y })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.popover !== null && snapshot.controls.popover.petId === visitor.id
  }, 2500, '点击客人出现送客弹层')
  state = await client.rendererState()
  const sendButton = state.uiRects.find((rect) => rect.id === 'ui:btn:end-visit')
  assert(Boolean(sendButton), '「送客」按钮有命中矩形')
  const sendPoint = rectCenterScreen(sendButton, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'click', x: sendPoint.x, y: sendPoint.y })
  const sendAction = await client.waitFrom(start, (event) => event.type === 'action' && event.action === 'end-visit', 3000, '送客申请')
  assert(sendAction.deviceId === visitorId, '送客申请带上访客的 deviceId')
  client.send({ type: 'action-result', id: sendAction.id, ok: true })

  // 放行卡：接受 → action=admit，成功后卡片收起。
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.prompt !== null
  }, 2000, '放行卡仍在')
  state = await client.rendererState()
  const admitButton = state.uiRects.find((rect) => rect.id === 'ui:btn:admit')
  assert(Boolean(admitButton), '「接受」按钮有命中矩形')
  const admitPoint = rectCenterScreen(admitButton, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'click', x: admitPoint.x, y: admitPoint.y })
  const admitAction = await client.waitFrom(start, (event) => event.type === 'action' && event.action === 'admit', 3000, '接受申请')
  assert(admitAction.deviceId === promptId, '接受申请带上放行卡的 deviceId')
  client.send({ type: 'action-result', id: admitAction.id, ok: true })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.prompt === null
  }, 2500, '接受后放行卡收起')

  // 置灰的「串门」：必须有可读理由；点它只冒泡，不发 action（不静默、也不假装成功）。
  const disabledScene = {
    ...scene,
    reset: false,
    controls: {
      ...scene.controls,
      visit: { enabled: false, reason: '还没有人放行你，宠物出不了门。' }
    }
  }
  client.send({ type: 'update', scene: disabledScene })
  await sleep(300)
  state = await client.rendererState()
  self = state.pets.find((pet) => pet.id === 'self')
  center = screenCenter(self, workArea)
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.popover !== null && snapshot.controls.popover.disabled.includes('visit')
  }, 2500, '置灰的串门按钮')
  state = await client.rendererState()
  const disabledButton = state.uiRects.find((rect) => rect.id === 'ui:btn:visit')
  const actionsBefore = client.events.filter((event) => event.type === 'action').length
  const disabledPoint = rectCenterScreen(disabledButton, workArea)
  client.send({ type: 'debug-dispatch', phase: 'click', x: disabledPoint.x, y: disabledPoint.y })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.notice !== null && /还没有人放行你/.test(snapshot.controls.notice.text)
  }, 2500, '点置灰按钮也有一句理由')
  assert(client.events.filter((event) => event.type === 'action').length === actionsBefore,
    '置灰按钮点击不会发 action（宿主不会收到一次假申请）')
  client.send({ type: 'debug-dispatch', phase: 'move', x: outside.x, y: outside.y })
  await client.waitStatus((status) => status.busy === false, 3000, '关掉置灰弹层并释放租约')

  // 自己出门：桌面没有 self → 常驻「召回」胶囊（否则召回按钮没有锚点）。
  const awayScene = shared.petScene([
    { id: 'visitor:' + visitorId, role: 'visitor', label: '阿蟹', anim: '螃蟹走路', color: shared.PET_COLORS[1] }
  ], workArea, {
    reset: true,
    controls: {
      visit: { enabled: false, reason: '宠物在「阿蟹」家，先召回再串门。' },
      recall: { enabled: true, nickname: '阿蟹' },
      visitors: [{ deviceId: visitorId, label: '阿蟹' }],
      prompt: null,
      notice: null
    }
  })
  client.send({ type: 'update', scene: awayScene })
  await waitUntil(async () => {
    const snapshot = await client.rendererState()
    return snapshot.controls.recallChip !== null
  }, 2500, '出门后出现召回胶囊')
  state = await client.rendererState()
  const chip = state.uiRects.find((rect) => rect.id === 'ui:recall-chip')
  assert(Boolean(chip), '召回胶囊有命中矩形（没有 self 时也能点）')
  const chipPoint = rectCenterScreen(chip, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'click', x: chipPoint.x, y: chipPoint.y })
  const recallAction = await client.waitFrom(start, (event) => event.type === 'action' && event.action === 'recall', 3000, '召回申请')
  assert(typeof recallAction.id === 'string' && recallAction.id !== '', '召回申请带 id')
  client.send({ type: 'action-result', id: recallAction.id, ok: true })

  // 收尾：quit 自己退出。
  const exitPromise = client.exited
  client.send({ type: 'quit' })
  const exit = await Promise.race([exitPromise, sleep(4000).then(() => null)])
  assert(exit !== null, '控件用例结束后 helper 自己退出')
  assert(exit.code === 0 || exit.code === null, '控件用例退出码正常（' + JSON.stringify(exit) + '）')

  return { pngPath, sidecarPath: pngPath + '.json', verified, noticeVerified }
}

// ---------------------------------------------------------------------------
// 2) 交互模式：点击穿透 / 输入租约 / 物理 / 场景对账 / 截图
// ---------------------------------------------------------------------------

async function verifyHelper () {
  const client = createHelperClient((line) => info(line))
  const readyMark = client.mark()
  const ready = await client.waitFrom(readyMark, (event) => event.type === 'ready', 15000, 'ready')
  assert(ready.pid === client.child.pid, 'ready.pid 就是 helper 进程（' + ready.pid + '）')
  assert(ready.workArea.width > 0 && ready.workArea.height > 0,
    'ready 上报主屏工作区 ' + ready.workArea.width + '×' + ready.workArea.height)
  assert(Array.isArray(ready.displays) && ready.displays.length >= 1, 'ready 上报显示器列表')
  assert(ready.debug === true && ready.shotMode === false, 'debug 模式已生效')
  const workArea = ready.workArea

  // 场景来之前先看默认态：窗口只在有宠物/卡片时才可能接管鼠标。
  let current = await client.status()
  assert(current.sceneItems === 0 && current.ignoring === true,
    '窗口默认点击穿透（ignoring=true，场景为空）')

  const scene = shared.demoPetScene(workArea)
  client.send({ type: 'update', scene })
  await sleep(700)
  current = await client.status()
  assert(current.sceneItems === scene.items.length, 'stdin 的 update 被接受（sceneItems=' + current.sceneItems + '）')
  assert(current.visible === true, '窗口已显示')
  assert(current.focused === false, '窗口不抢焦点（focused=false）')
  assert(current.focusable === false, '窗口不可聚焦（focusable=false）')
  assert(current.alwaysOnTop === true, '窗口置顶（alwaysOnTop=true）')
  assert(current.allWorkspaces === true, '窗口显示在所有工作区（allWorkspaces=true）')
  assert(current.bounds.width === workArea.width && current.bounds.height === workArea.height,
    '窗口尺寸等于工作区，不越界')
  // 冒烟只走合成 PointerEvent：锁住真实输入，环境里的鼠标/焦点事件不能干扰用例。
  client.send({ type: 'debug-lock-input', locked: true })
  await sleep(150)
  client.send({ type: 'debug-dispatch', phase: 'move', x: workArea.x + 8, y: workArea.y + 8 })
  await sleep(150)
  assert((await client.status()).ignoring === true, '锁住输入后窗口回到穿透（没有悬停）')
  current = await client.waitStatus((status) => status.rendererRects >= 3, 4000, '渲染端上报 3 个命中矩形')
  assert(current.rendererRectsAgeMs !== null && current.rendererRectsAgeMs < shared.RENDERER_RECT_MAX_AGE_MS,
    '命中矩形是新鲜的（' + current.rendererRectsAgeMs + 'ms）')

  // 等出生速度被地面摩擦吃掉：命中判定是在宠物静止时做的，避免测试和物理赛跑。
  await sleep(2600)
  let state = await client.rendererState()
  assert(state !== null && state.pets.length === 3, '渲染端有 3 只宠物')
  assert(state.pets.every((pet) => pet.x >= 0 && pet.y >= 0 &&
    pet.x + pet.width <= workArea.width + 0.5 && pet.y + pet.height <= workArea.height + 0.5),
  '所有宠物都在工作区内（出生后立即受重力/夹取约束）')
  if (ASSET_ROOTS.length > 0) {
    assert(state.pets.every((pet) => pet.source === 'video'),
      '宠物素材经 localpet:// 加载成功（' + state.pets.map((pet) => pet.clip).join(', ') + '）')
  }
  assert(state.pets.every((pet) => Number.isFinite(pet.vx) && Number.isFinite(pet.vy)), '速度是有限数')

  // 渲染端悬停路径（真实输入管线）：sendInputEvent 的合成 mousemove → 渲染端 hover → IPC。
  // 宠物可能刚出生还在动，重试几次拿新鲜位置；之后锁住真实输入，后续全用 debug-dispatch。
  const outside = { x: workArea.x + 8, y: workArea.y + 8 }
  // 真实输入管线单独验一次：解锁 → sendInputEvent mousemove → 命中；验完立刻重新锁上。
  client.send({ type: 'debug-lock-input', locked: false })
  await sleep(150)
  let hovered = null
  let hoveredPet = null
  let self = null
  let center = null
  let start = 0
  for (let attempt = 1; attempt <= 3 && hovered === null; attempt += 1) {
    state = await client.rendererState()
    hoveredPet = state.pets.find((pet) => pet.id === 'self')
    center = screenCenter(hoveredPet, workArea)
    start = client.mark()
    client.send({ type: 'debug-move', x: center.x, y: center.y })
    try {
      hovered = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 1500, '进入命中区')
    } catch {
      info('真实输入悬停第 ' + attempt + ' 次没中，重试')
      client.send({ type: 'pointer', x: outside.x, y: outside.y })
      await sleep(250)
      hovered = null
    }
  }
  assert(hovered !== null, '真实输入管线（sendInputEvent mousemove）能触发命中')
  assert(hovered.inside === true && hovered.itemId === 'self', '光标进命中区 → 命中 self（itemId=self）')
  assert(['hovering', 'main-fallback'].includes(hovered.reason), '渲染端路径接管鼠标（reason=' + hovered.reason + '）')
  assert(hitMatchesPet(hovered, hoveredPet, workArea), 'hit.rect 与渲染端上报的宠物矩形一致（屏幕 DIP）')

  // 重新锁住真实输入，用合成 PointerEvent 做确定性的悬停/穿透判定。
  client.send({ type: 'debug-lock-input', locked: true })
  await sleep(150)
  state = await client.rendererState()
  // 用 guest 做“主进程否决/兜底”：悬停 self 会弹控件并持有租约（ticket 11），
  // 而这里要验证的恰恰是“没有租约时，位置判定必须听真实光标的”。guest 悬停不弹控件。
  const hoverGuest = state.pets.find((pet) => pet.id === 'guest:demo-a')
  center = screenCenter(hoverGuest, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  const synthHover = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '合成悬停')
  assert(synthHover.itemId === hoverGuest.id, '合成 pointermove 也能命中 guest（' + synthHover.itemId + '）')
  assert((await client.status()).ignoring === false, '主进程真的调用了 setIgnoreMouseEvents(false)')

  // 主进程否决：渲染端还在说 inside，但真实光标在外面
  start = client.mark()
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  const vetoed = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === false, 2000, '主进程否决')
  assert(vetoed.reason === 'outside', '渲染端说 inside 也不能否决「真实光标在外面」')
  assert((await client.status()).ignoring === true, '恢复穿透')

  // 主进程兜底：先让渲染端真的看见光标离开，再只改主进程光标（渲染端完全没消息）
  client.send({ type: 'debug-dispatch', phase: 'move', x: outside.x, y: outside.y })
  await sleep(1300)
  center = screenCenter(hoverGuest, workArea)
  start = client.mark()
  client.send({ type: 'pointer', x: center.x, y: center.y })
  const fallback = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '兜底接管')
  assert(fallback.reason === 'main-fallback', '渲染端无消息时，停留 300ms 由主进程兜底接管')
  await leavePointer(client, outside)
  assert((await client.status()).ignoring === true, '兜底接管后移出命中区也恢复穿透')

  // 输入租约 + ui:drag（A3）：拖拽时宠物落后于光标，租约负责让位置判定让位；
  // 但租约**不能单独**让整窗可交互——光标必须压在一条活的命中矩形上。
  // 外部应用抢焦点会让 helper 收到 blur 并（正确地）收回租约；这是环境事件，不是被测行为，
  // 所以这里最多重试 3 次。
  let leaseHeld = false
  let dragPoint = null
  for (let attempt = 1; attempt <= 3 && !leaseHeld; attempt += 1) {
    state = await client.rendererState()
    self = state.pets.find((pet) => pet.id === 'self')
    center = screenCenter(self, workArea)
    start = client.mark()
    client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
    await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '拖拽前悬停')
    const before = self
    client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
    current = await client.waitStatus((status) => status.busy === true, 2000, '拖拽开始（busy=true）')
    assert(current.ignoring === false, '拖拽开始后窗口可交互')
    state = await client.rendererState()
    assert(state.dragging === 'self', '渲染端记录了拖拽中的宠物（dragging=self）')
    const grabbed = state.pets.find((pet) => pet.id === 'self')
    assert(Math.abs(grabbed.x - before.x) < 3 && Math.abs(grabbed.y - before.y) < 3,
      '刚按下时宠物还在原地（弹簧跟随，不瞬移）')

    // 把光标甩到右边 260px：弹簧跟随需要时间，此刻光标已经在宠物矩形外，
    // 但渲染端上报的 ui:drag（宠物 ∪ 光标周围 80px）必须把它盖住。
    dragPoint = { x: center.x + 260, y: center.y - 40 }
    client.send({ type: 'debug-dispatch', phase: 'move', x: dragPoint.x, y: dragPoint.y })
    await sleep(120)
    state = await client.rendererState()
    const lagging = state.pets.find((pet) => pet.id === 'self')
    const dragRects = state.uiRects.filter((rect) => rect.id === 'ui:drag')
    assert(dragRects.length === 1, '拖拽期间上报了一条跟随光标的 ui:drag 矩形')
    const localDragPoint = { x: dragPoint.x - workArea.x, y: dragPoint.y - workArea.y }
    assert(shared.hitTestRects(dragRects, localDragPoint) !== null, 'ui:drag 矩形盖住了光标')
    assert(shared.hitTestRects(
      [{ x: lagging.x, y: lagging.y, width: lagging.width, height: lagging.height }],
      localDragPoint
    ) === null, '光标确实在（落后的）宠物矩形外：靠租约 + ui:drag 接管鼠标')
    current = await client.status()
    if (current.busy === true && current.ignoring === false) {
      leaseHeld = true
    } else {
      info('输入租约被外部焦点变化打断（第 ' + attempt + ' 次），重试')
      client.send({ type: 'debug-dispatch', phase: 'up', x: dragPoint.x, y: dragPoint.y })
      await sleep(250)
      await leavePointer(client, outside)
    }
  }
  assert(leaseHeld, '光标在宠物矩形外、却压在 ui:drag 上时窗口保持可交互（输入租约生效）')

  // A3：租约还在续期，但主进程光标离开所有活矩形 → 必须恢复穿透。
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  current = await client.waitStatus((status) => status.ignoring === true, 3000, '租约不能单独占住桌面')
  assert(current.busy === true, '此时租约仍然新鲜：穿透不是因为租约过期，而是因为没有活矩形')
  state = await client.rendererState()
  assert(state.dragging === 'self', '渲染端还在拖拽，窗口依然恢复穿透（fail closed）')

  // 光标回到 ui:drag 上 → 立刻恢复可交互，拖拽没断。
  client.send({ type: 'pointer', x: dragPoint.x, y: dragPoint.y })
  await client.waitStatus((status) => status.ignoring === false, 3000, '回到拖拽矩形恢复可交互')
  assert((await client.rendererState()).dragging === 'self', '拖拽没有被打断')

  // pointerup → 释放租约；宠物不会因为光标在外面而弹飞
  client.send({ type: 'debug-dispatch', phase: 'up', x: dragPoint.x, y: dragPoint.y })
  current = await client.waitStatus((status) => status.busy === false, 2500, '拖拽结束释放租约')
  assert(current.busy === false, 'pointerup 立刻释放租约（不再靠租约兜底）')
  // 没有租约兜底之后，光标一移开就必须立刻回穿透。
  start = client.mark()
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === false, 2500, '拖拽结束交还穿透')
  current = await client.status()
  assert(current.busy === false, 'pointerup 后 busy 释放')
  assert(current.ignoring === true, 'pointerup 后恢复穿透')
  state = await client.rendererState()
  assert(state.dragging === null, '渲染端拖拽状态已清空')
  self = state.pets.find((pet) => pet.id === 'self')
  // 松手位置比抓起来时高 40px，宠物会自然下落（vy ≠ 0 是重力，不是投掷）。
  assert(Math.abs(self.vx) < 30, '没有新轨迹就松手 → 不投掷（水平速度≈0）')

  // 拖拽跟手 + 投掷
  center = screenCenter(self, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '投掷前悬停')
  client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
  await client.waitStatus((status) => status.busy === true, 2000, '投掷拖拽开始')
  const dragStart = (await client.rendererState()).pets.find((pet) => pet.id === 'self')
  await sleep(100)
  const midX = center.x + 140
  const midY = center.y - 70
  client.send({ type: 'debug-dispatch', phase: 'move', x: midX, y: midY })
  await sleep(80)
  const endX = center.x + 300
  const endY = center.y - 150
  client.send({ type: 'debug-dispatch', phase: 'move', x: endX, y: endY })
  await sleep(50)
  const following = (await client.rendererState()).pets.find((pet) => pet.id === 'self')
  assert(following.x > dragStart.x + 50, '拖拽时宠物朝光标方向跟随（' + dragStart.x.toFixed(0) + ' → ' + following.x.toFixed(0) + '）')
  client.send({ type: 'debug-dispatch', phase: 'up', x: endX, y: endY })
  await sleep(120)
  state = await client.rendererState()
  const thrown = state.pets.find((pet) => pet.id === 'self')
  const throwSpeed = Math.hypot(thrown.vx, thrown.vy)
  assert(throwSpeed > 100, '松手带上了释放速度（' + throwSpeed.toFixed(0) + ' px/s）')
  assert(state.pets.every((pet) => pet.x >= 0 && pet.y >= 0 &&
    pet.x + pet.width <= workArea.width + 0.5 && pet.y + pet.height <= workArea.height + 0.5),
  '投掷瞬间所有宠物仍在工作区内')
  await sleep(2500)
  state = await client.rendererState()
  const landed = state.pets.find((pet) => pet.id === 'self')
  assert(Math.hypot(landed.vx, landed.vy) < throwSpeed, '投掷速度随时间衰减（' + throwSpeed.toFixed(0) + ' → ' + Math.hypot(landed.vx, landed.vy).toFixed(0) + '）')
  assert(landed.y + landed.height <= workArea.height + 0.5, '落地后没有穿出工作区底边')

  // 移动中的命中矩形：主进程的命中判定跟着渲染端位置走
  state = await client.rendererState()
  const guest = state.pets.find((pet) => pet.id === 'guest:demo-a')
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: screenCenter(guest, workArea).x, y: screenCenter(guest, workArea).y })
  const movedHit = await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '移动后命中')
  assert(movedHit.itemId === guest.id, '移动后命中的是正确的那只（' + movedHit.itemId + '）')
  assert(hitMatchesPet(movedHit, guest, workArea), '命中矩形与渲染端当前位置一致')
  await leavePointer(client, outside)

  // 场景 v2：宿主删一只 → 渲染端立刻销毁；再加回来 → 重新出生
  const remaining = shared.petScene(scene.items
    .filter((item) => item.id !== 'guest:demo-b')
    .map((item) => ({ id: item.id, role: item.role, label: item.label, anim: item.anim, color: item.color })), workArea, { reset: true })
  client.send({ type: 'update', scene: remaining })
  await sleep(350)
  state = await client.rendererState()
  assert(state.pets.length === 2, '宿主删掉一只宠物后渲染端只剩 2 只（' + state.pets.map((pet) => pet.id).join(',') + '）')
  assert(state.pets.every((pet) => pet.id !== 'guest:demo-b'), '被删的宠物不再出现在渲染端')

  const restored = shared.petScene(scene.items.map((item) => ({
    id: item.id,
    role: item.role,
    label: item.label,
    anim: item.anim,
    color: item.color
  })), workArea, { reset: true })
  client.send({ type: 'update', scene: restored })
  await sleep(350)
  state = await client.rendererState()
  assert(state.pets.length === 3, '场景加回来 → 渲染端重新出生 3 只')
  assert(state.pets.every((pet) => pet.x >= 0 && pet.y >= 0 &&
    pet.x + pet.width <= workArea.width + 0.5 && pet.y + pet.height <= workArea.height + 0.5),
  'reset 后的宠物仍在工作区内')

  // 动作/昵称更新（宿主仍是动画/名字的权威）
  const renamed = shared.normalizeScene({
    ...restored,
    reset: false,
    items: restored.items.map((item) => item.id === 'self'
      ? { ...item, label: '小蓝二号', anim: '原地小憩沉眠' }
      : item)
  })
  client.send({ type: 'update', scene: renamed })
  await sleep(400)
  state = await client.rendererState()
  const renamedPet = state.pets.find((pet) => pet.id === 'self')
  assert(renamedPet.label === '小蓝二号' && renamedPet.anim === '原地小憩沉眠', '昵称/动作跟着宿主场景更新')
  assert(renamedPet.source === 'video' || renamedPet.source === 'loading', '动作更新后仍走 WebM 素材')

  // 渲染端冻结：hover 通道完全没消息时，主进程兜底也必须停（fail-closed）
  await sleep(2600)
  state = await client.rendererState()
  const freezeTarget = state.pets.find((pet) => pet.id === 'self')
  client.send({ type: 'debug-freeze-hover', frozen: true })
  client.send({ type: 'pointer', x: screenCenter(freezeTarget, workArea).x, y: screenCenter(freezeTarget, workArea).y })
  await sleep(900)
  current = await client.status()
  assert(current.ignoring === true, '渲染端冻结时，主进程兜底不会接管（依旧穿透）')
  client.send({ type: 'debug-freeze-hover', frozen: false })
  await leavePointer(client, outside)

  // 输入租约超时：busy 心跳不再续期时，超过 BUSY_LEASE_MS 自动收回
  state = await client.rendererState()
  self = state.pets.find((pet) => pet.id === 'self')
  center = screenCenter(self, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, '超时前悬停')
  client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
  await client.waitStatus((status) => status.busy === true, 2000, '超时拖拽开始')
  client.send({ type: 'debug-freeze-busy', frozen: true })
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  // 光标先离开命中区（立刻穿透是 A3 的正确行为），再等租约自己过期。
  current = await client.waitStatus((status) => status.ignoring === true, 3000, '离开拖拽矩形恢复穿透')
  assert(current.busy === true, '这时租约还没过期：穿透来自“没有活矩形”，不是租约失效')
  current = await client.waitStatus((status) => status.busy === false, shared.BUSY_LEASE_MS + 2500, '租约超时释放')
  assert(current.ignoring === true, 'BUSY_LEASE_MS 内没有续期 → 租约自动释放（busy=false）')
  client.send({ type: 'debug-dispatch', phase: 'up', x: outside.x, y: outside.y })
  client.send({ type: 'debug-freeze-busy', frozen: false })
  await sleep(200)
  assert((await client.status()).ignoring === true, '渲染端也收手后仍是穿透（不残留输入租约）')

  // window blur 也要交还租约（真实环境里临时解锁输入，测完立刻锁回去）
  client.send({ type: 'debug-lock-input', locked: false })
  await sleep(150)
  state = await client.rendererState()
  self = state.pets.find((pet) => pet.id === 'self')
  center = screenCenter(self, workArea)
  start = client.mark()
  client.send({ type: 'debug-dispatch', phase: 'move', x: center.x, y: center.y })
  await client.waitFrom(start, (event) => event.type === 'hit' && event.interactive === true, 3000, 'blur 前悬停')
  client.send({ type: 'debug-dispatch', phase: 'down', x: center.x, y: center.y })
  await client.waitStatus((status) => status.busy === true, 2000, 'blur 前拖拽')
  client.send({ type: 'pointer', x: outside.x, y: outside.y })
  client.send({ type: 'debug-dispatch', phase: 'blur', x: center.x, y: center.y })
  await sleep(250)
  current = await client.status()
  assert(current.busy === false && current.ignoring === true, 'window blur → 渲染端立刻交还输入租约并恢复穿透')
  client.send({ type: 'debug-lock-input', locked: true })
  await sleep(150)

  // 截图：宠物 + 昵称 + 透明背景
  mkdirSync(OUT_DIR, { recursive: true })
  const pngPath = join(OUT_DIR, 'helper.png')
  start = client.mark()
  client.send({ type: 'shot', id: 'shot-helper', path: pngPath })
  const shot = await client.waitFrom(start, (event) => event.type === 'shot', 8000, 'shot')
  assert(existsSync(pngPath), 'shot 落盘：' + pngPath)
  assert(shot.width > 0 && shot.height > 0, 'shot 返回像素尺寸 ' + shot.width + '×' + shot.height)
  const verified = verifyShot(pngPath, pngPath + '.json', 3)
  info('交互截图：' + pngPath)

  // quit：进程自己退出
  const exitPromise = client.exited
  client.send({ type: 'quit' })
  const exit = await Promise.race([exitPromise, sleep(4000).then(() => null)])
  assert(exit !== null, 'quit 命令让 helper 自己退出')
  assert(exit.code === 0 || exit.code === null, 'quit 退出码正常（' + JSON.stringify(exit) + '）')
  return { pngPath, sidecarPath: pngPath + '.json', verified }
}

// ---------------------------------------------------------------------------
// 3) manager：宿主侧生命周期 + 宠物场景
// ---------------------------------------------------------------------------

function pidAlive (pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch {
    return false
  }
}

async function waitUntil (predicate, timeoutMs, label) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (await predicate()) return true
    await sleep(50)
  }
  throw new Error('等待超时：' + label)
}

async function verifyManager () {
  const infos = []
  const warns = []
  const manager = createDesktop({
    desktopHost: true,
    platform: 'darwin',
    debug: true,
    assetRoots: ASSET_ROOTS,
    log: { info: (line) => { infos.push(line); info(line) }, warn: (line) => { warns.push(line); info(line) } }
  })
  try {
    const started = manager.start()
    assert(started.ok === true, 'manager 启动 helper（pid ' + started.pid + '）')
    await waitUntil(() => manager.status().ready, 15000, 'manager ready')
    const workArea = manager.status().workArea
    assert(workArea.width > 0, 'manager 收到 ready 工作区')
    assert(manager.status().assetRoots.length === ASSET_ROOTS.length, 'manager 把素材目录传给了 helper')
    const scene = shared.petScene([
      { id: 'self', role: 'self', label: '小蓝', anim: '东张西望', color: shared.PET_COLORS[0] },
      { id: 'guest:manager', role: 'guest', label: '阿蟹', anim: '螃蟹走路', color: shared.PET_COLORS[1] }
    ], workArea)
    assert(manager.update(scene) === true, 'manager 把宠物场景写进 stdin')
    await sleep(1400)
    const status = await manager.requestStatus()
    assert(status.ok === true && status.status.sceneItems === 2, 'helper 应用了宠物场景（sceneItems=2）')
    const pngPath = join(OUT_DIR, 'manager.png')
    const shot = await manager.shot(pngPath)
    assert(shot.ok === true && existsSync(pngPath), 'manager 的 shot 命令落盘（' + shot.width + '×' + shot.height + '）')
    verifyShot(pngPath, pngPath + '.json', 2)

    const firstPid = manager.pid
    process.kill(firstPid, 'SIGKILL')
    await waitUntil(() => manager.status().pid !== null && manager.status().pid !== firstPid, 8000, '崩溃后重启')
    assert(warns.some((line) => /退出/.test(line) && /重启/.test(line)), '宿主为 helper 崩溃打了一行日志')
    assert(manager.status().restarts === 1, '重启计数 = 1')
    await waitUntil(() => manager.status().ready, 10000, '重启后 ready')
    // 强制整包对账：即使场景没变也让渲染端重新出生（helper 重启后宿主可以这么做）
    assert(manager.resync({ ...scene, reset: false }) === true, 'manager.resync 能强制整包对账')
    await sleep(500)
    const status2 = await manager.requestStatus()
    assert(status2.ok === true && status2.status.sceneItems === 2, '重启后场景生效')

    const secondPid = manager.pid
    manager.dispose()
    await waitUntil(() => !pidAlive(secondPid), 5000, 'dispose 后 helper 消失')
    assert(manager.status().running === false, 'dispose 后 manager 不再报告运行')
    assert(!pidAlive(firstPid) && !pidAlive(secondPid), '两个 helper 进程都已离开')
  } finally {
    manager.dispose()
  }

  // 不可用：只打一行、不 spawn
  const unavailableInfos = []
  const unavailable = createDesktop({
    desktopHost: false,
    log: { info: (line) => unavailableInfos.push(line), warn: (line) => unavailableInfos.push(line) }
  })
  const unavailableResult = unavailable.start()
  assert(unavailableResult.reason === 'not-desktop-host', 'web profile / 非桌面宿主 → not-desktop-host')
  assert(unavailableInfos.length === 1, '降级只打一行日志')
  unavailable.dispose()

  const missingWarns = []
  const missing = createDesktop({
    desktopHost: true,
    platform: 'darwin',
    env: { DSH_HOME: '/nonexistent-dsh-home-for-smoke' },
    exists: () => false,
    log: { info: () => {}, warn: (line) => missingWarns.push(line) }
  })
  const missingResult = missing.start()
  assert(missingResult.reason === 'electron-missing', 'Electron 缺失 → electron-missing')
  assert(missingWarns.length === 1, 'Electron 缺失只打一行日志')
  missing.dispose()
}

// ---------------------------------------------------------------------------
// 4) 宿主被 SIGKILL：helper 必须自己发现并退出
// ---------------------------------------------------------------------------

async function verifyHostKill () {
  const hostScript = join(OUT_DIR, 'host-child.mjs')
  mkdirSync(OUT_DIR, { recursive: true })
  writeFileSync(hostScript, `
import { createDesktop } from ${JSON.stringify(new URL('../src/desktop.js', import.meta.url).href)}
const manager = createDesktop({
  desktopHost: true,
  platform: 'darwin',
  assetRoots: ${JSON.stringify(ASSET_ROOTS)},
  log: { info() {}, warn() {} }
})
const started = manager.start()
process.stdout.write(JSON.stringify(started) + '\\n')
setInterval(() => {}, 1000)
`, 'utf8')
  const host = spawn(process.execPath, [hostScript], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] })
  spawned.push(host)
  let stdout = ''
  host.stdout.setEncoding('utf8')
  host.stdout.on('data', (chunk) => { stdout += chunk })
  let stderr = ''
  host.stderr.setEncoding('utf8')
  host.stderr.on('data', (chunk) => { stderr += chunk })
  const deadline = Date.now() + 15000
  while (Date.now() < deadline && !stdout.includes('\n')) await sleep(50)
  const line = stdout.split('\n').find((candidate) => candidate.includes('"pid"'))
  assert(Boolean(line), '宿主子进程拉起了 helper')
  const started = JSON.parse(line)
  const helperPid = started.pid
  assert(pidAlive(helperPid), 'helper 在跑（pid ' + helperPid + '）')

  process.kill(host.pid, 'SIGKILL')
  const gone = await waitUntil(() => !pidAlive(helperPid), 10000, '宿主被杀后 helper 自行退出')
  assert(gone, '宿主被 SIGKILL 后，helper 在 10s 内自行退出（host-liveness / 管道断开）')
  if (stderr.trim() !== '') info('宿主子进程 stderr：' + stderr.trim().slice(0, 500))
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

function cleanup () {
  for (const child of spawned) {
    try {
      if (child.exitCode === null) child.kill('SIGKILL')
    } catch {
      // ignore
    }
  }
}

let exitCode = 0
let shot = null
try {
  rmSync(OUT_DIR, { recursive: true, force: true })
  mkdirSync(OUT_DIR, { recursive: true })
  console.log('Electron: ' + (resolveElectronBinary({}).path ?? '未找到'))
  console.log('dsh-pet 素材: ' + (ASSET_ROOTS.length > 0 ? ASSET_ROOTS.join(' | ') : '未找到（将退化为 SVG 色块）'))
  console.log('输出目录: ' + OUT_DIR)
  if (WRITE_NOTES) console.log('截图笔记: ' + NOTES_DIR)
  const standalone = await run('截图模式：三只演示宠物 + 透明背景 + 真实素材', verifyShotMode)
  await run('降级：没有 dsh-pet 素材时退到内置 SVG 色块', verifySvgFallback)
  await run('helper：点击穿透 / 输入租约 / 物理 / 场景 v2 / 截图 / quit', verifyHelper)
  const controls = await run('控件：悬停弹层 / 点击穿透（A2）/ 租约 fail-closed（A3）/ 串门申请 / 失败气泡 / 放行卡 / 送客 / 召回', verifyControls)
  await run('manager：ready / update / resync / shot / 崩溃重启 / dispose', verifyManager)
  await run('生命周期：宿主被 SIGKILL 后 helper 自行退出', verifyHostKill)
  const notes = writeNoteScreenshots(standalone.verified)
  const controlNotes = writeControlNotes(controls.verified, controls.noticeVerified)
  if (notes !== null) {
    console.log('\n截图笔记：')
    console.log('  整窗（棋盘格合成）: ' + notes.fullPath)
    console.log('  宠物特写（棋盘格合成）: ' + notes.cropPath)
  }
  if (controlNotes !== null) {
    console.log('  控件整窗（棋盘格合成）: ' + controlNotes.fullPath)
    console.log('  控件特写（棋盘格合成）: ' + controlNotes.cropPath)
    console.log('  失败气泡特写（棋盘格合成）: ' + controlNotes.noticePath)
  }
  console.log('\n全部通过（' + checks + ' 项断言）。')
  console.log('交互截图：' + join(OUT_DIR, 'helper.png'))
  console.log('控件截图：' + controls.pngPath)
  console.log('截图模式输出：' + standalone.pngPath)
} catch (error) {
  exitCode = 1
  console.error('\n冒烟失败：' + (error instanceof Error ? error.message : String(error)))
  if (error instanceof Error && error.stack) console.error(error.stack)
  console.error('辅助日志目录：' + OUT_DIR)
} finally {
  cleanup()
}
process.exit(exitCode)
